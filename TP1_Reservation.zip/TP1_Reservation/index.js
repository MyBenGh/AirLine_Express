const bodyParser = require('body-parser');
const dateFormat = require('dateformat');
const express = require('express');
const mysql = require('mysql');
const http = require('http');
const now = new Date();
const app = express();
const siteTitle = "Airline Express";
const baseURL = "http://localhost:3000/";

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended: true }));
module.exports = app;

/*app.listen(process.env.PORT || 3000,() => {​​
    console.log ( 'Application démarrée sur PORT $ {​​ process. env . PORT || 3000 }​​ ' ) ;
}​​ ) ;*/
var server = app.listen(3000, function(){
    console.log("serveur fonctionne sur 3000... ! ");
});


app.set('view engine', 'ejs');

/**
 * Import all related javascript and css files to inject in our app
 *  */ 
app.use('/js', express.static(__dirname + '/node_modules/bootstrap/dist/css'));
app.use('/js', express.static(__dirname + '/node_modules/bootstrap/dist/js'));
app.use('/js', express.static(__dirname + '/node_modules/tether/dist/js'));
app.use('/js', express.static(__dirname + '/node_modules/jquery/dist'));
app.use(express.static(__dirname + "/public"));


/**
* connexion à la BD
*/
const con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "db_airline_express"
});


/*
Page D'accueil: Explication du but de la compagnie
*/
app.get('/',function (req,res) {
    //res.end('Vous êtes à l\'accueil');
    res.render('pages/index',{
        siteTitle : siteTitle,
        pageTitle : "Page d'accueil"
    });
});



/*
Afficher la liste des vols
*/
app.get('/Vols',function (req,res) {
    /*
    Afficher tous les enrégistrements de la table vol
    */
    con.query("SELECT * FROM vol ORDER BY id_vol", function (
    err, result){
        res.render('pages/liste_vols.ejs',{
            siteTitle : siteTitle,
            pageTitle : "Liste des vols offerts",
            items : result
        });
    });
});

/*
Page De contact au cas où le client souhaite nous joindre
*/
app.get('/Contacts',function (req,res) {
    //res.end('Vous êtes à l\'accueil');
    res.render('pages/contact.ejs',{
        siteTitle : siteTitle,
        pageTitle : "Page de contact"
    });
});

/*
Effectuer les différentes réservations
*/
app.get('/Reservation',function (req,res) {
    /*
    Afficher tous les enrégistrements de la table vol
    */
    con.query("SELECT * FROM vol ORDER BY id_vol", function (
    err, result){
        res.render('pages/reservation.ejs',{
            siteTitle : siteTitle,
            pageTitle : "Liste des vols offerts",
            items : result
        });
    });
});


/*
Ouvrir un compte ou consulter les activités de son compte
*/
app.get('/Compte',function (req,res) {
    /*
    Afficher tous les enrégistrements de la table vol
    */
    con.query("SELECT * FROM vol ORDER BY id_vol", function (
    err, result){
        res.render('pages/compte.ejs',{
            siteTitle : siteTitle,
            pageTitle : "Liste des vols offerts",
            items : result
        });
    });
});

/*
Facture de la réservation
*/
app.get('/Reservation/Facture',function (req,res) {
    /*
    Afficher tous les enrégistrements de la table vol
    */
    con.query("SELECT * FROM vol ORDER BY id_vol", function (
    err, result){
        res.render('pages/facture.ejs',{
            siteTitle : siteTitle,
            pageTitle : "Liste des vols offerts",
            items : result
        });
    });
});


/*Creer connexion*/
app.get('/compte/creercompte', function (req, res) {
    /*
    Afficher tous les enregistrements de la table vol
    */
    con.query("SELECT * FROM client ORDER BY id_client", function (
        err, result) {
        res.render('pages/creercompte.ejs', {
            siteTitle: siteTitle,
            pageTitle: "Creation de compte",
            items: result

        });
    });
});

app.post('/compte/creercompte', function (req, res) {
    /* get the record base on ID
    */
    var query = "INSERT INTO client (prenom_client, nom_client, date_naissance, courriel) VALUES (";
    query += " '" + req.body.prenom_client + "',";
    query += " '" + req.body.nom_client + "',";
    query += " '" + dateFormat(req.body.date_naissance, "yyyy-mm-dd") + "',";
    query += " '" + req.body.courriel + "')";

    console.log (query);
    con.query(query, function (err, result) {
        if (err) throw err;
        res.redirect(baseURL);
    });
});








