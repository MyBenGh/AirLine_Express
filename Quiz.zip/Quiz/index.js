const bodyParser = require('body-parser');
const express = require('express');
const routeur = express.Router ( ) ;
const mysql = require('mysql');
const http = require('http');
const Vue = require('vue');
const app = express();
const siteTitle = "Framework VUEJS";
const baseURL = "http://localhost:3000/";

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
module.exports = app;

var server = app.listen(3000, function(){
    console.log("serveur fonctionne sur 3000... ! ");
});


app.set('view engine', 'ejs');

/**
 * Import all related javascript and css files to inject in our app
 *  */ 
app.use('/js', express.static(__dirname + '/node_modules/bootstrap/dist/css'));
app.use('/js', express.static(__dirname + '/node_modules/bootstrap/dist/js'));
app.use('/js', express.static(__dirname + '/node_modules/tether/dist/js'));
app.use('/js', express.static(__dirname + '/node_modules/jquery/dist'));
app.use ( express.static ( __dirname + '/views/pages' ) ) ;
app.use(express.static(__dirname + "/public"));

/**
* connexion à la BD
*/
const con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "dbtest"
});

/*
Page D'accueil: Explication du but de la compagnie
*/
app.get('/',function (req,res) {
  //res.end('Vous êtes à l\'accueil');
  res.render('pages/telephone.ejs',{
      siteTitle : siteTitle,
      pageTitle : "Liste telephones"
  });
});


/*
Page D'ajout: Réccupère les données à ajouter à la base de données
*/
app.get('/ajout',function (req,res) {
  //res.end('Vous êtes à l\'accueil');
  res.render('pages/ajout.ejs',{
      siteTitle : siteTitle,
      pageTitle : "Page ajout"
  });
});


/*
Page D'ajout: enrégistre les données dans la base de données
*/
app.post('/ajout',function (req,res) {
  
  var query = "INSERT INTO telephone (prix, modele, marque) VALUES (";
    query += " '"+req.body.prix+"',";
    query += " '"+req.body.modele+"',";
    query += " '"+req.body.marque+"')";

    con.query(query, function (err, result){
        if (err) throw err;
        res.redirect(baseURL);
    });

});

var  vm1 = new Vue({
  el: '#affichage',
  data: {
      firstname : "Ria",
      lastname  : "Singh",
      imgsrc : "/images/telephone.png",
      htmlcontent : "<div><h1>Ajout de telephone</h1></div>"
  },
  methods: {
      mydetails : function() {
          return "I am "+this.firstname +" "+ this.lastname;
      }
  }
});

console.log(vm1.firstname);

  
